import { Injectable } from '@angular/core';

import {PLAYERS} from '../players'
import { MessageService } from '../message.service';

import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError} from 'rxjs/operators';
import { Player } from '../player';


@Injectable({
  providedIn: 'root'
})
export class PlayerService {


  constructor(private messageService: MessageService,
    private _client : HttpClient) { }

    /*getPlayers(): Observable<Player[]> {
      return this._client.get<Player[]>(this.playersUrl);
    }*/


  getPlayers(): Observable<Player[]> {
      let url = "https://jsonplaceholder.typicode.com/users";
      //let url = "https://rest.cricketapi.com/rest/v3/players_list";
      //let url ="https://celebritybucks.com/developers/export/JSON?limit=10"
      let _header = new HttpHeaders().set('content-type', 'application/json');
      return this._client.get<Player []>(url, { headers:_header }
      ).pipe(
        catchError(this.handleError('getPlayers', []))
      );
 }


 private handleError<T> (operation = 'operation', result?: T) {
  return (error: any): Observable<T> => {
    console.error(error);
    return of(result as T);
  };
}

 /*getPlayers(): Observable<Player[]> {

  //this.messageService.add('PlayerService: fetched players');
  return of(PLAYERS);
 }*/

  getPlayer(id: number): Observable<any> {
      let url = "https://jsonplaceholder.typicode.com/users/"+id;
      let _header = new HttpHeaders().set('content-type', 'application/json');
      return this._client.get<Player>(url, { headers:_header })
      .pipe(
        catchError(this.handleError('getPlayer', []))
      );
  }

  /*getPlayer(id: number): Observable<any> {
    //this.messageService.add(`HeroService: fetched hero id=${id}`);
    //return of(PLAYERS.find(player => player.id === id));
  }*/
}
