import { Component, OnInit } from '@angular/core';
import { FooterComponent } from '../footer/footer.component';
import { LocalStorage } from '../local-storage';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private footer : FooterComponent, 
    private _router : Router,
    private localStorage : LocalStorage) { }

  ngOnInit() {
  }

  isLoggedIn() : boolean{
    return this.footer.isLoggedIn();
  }

  logOut() : void {
    this.localStorage.deleteAuthToken("AUTH_TOKEN");
    this._router.navigateByUrl('login');
  }

}
