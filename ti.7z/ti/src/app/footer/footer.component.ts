import { Component, OnInit } from '@angular/core';
import {DashboardComponent} from '../dashboard/dashboard.component'
import { LocalStorage } from '../local-storage';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

    login: boolean=false;

    constructor(private dashboard : DashboardComponent,private localStorage : LocalStorage){}

   ngOnInit(){
    this.login =this.dashboard.login;
    console.log("inside FooterComponent ngOnInit :"+this.dashboard.login);
  }

  isLoggedIn(): boolean {
    
    console.log("inside isLoggedIn");
    let token = this.localStorage.getAuthToken("AUTH_TOKEN");
    if (token == "undefined" || token == null) {
      console.log("inside isLoggedIn : false")
      return false;
    }
    console.log("inside isLoggedIn : true");
    return true;
  }

}
