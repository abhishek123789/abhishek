import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {PlayersComponent} from './players/players.component'
import { DashboardComponent }   from './dashboard/dashboard.component';
import { PlayerDetailComponent }  from './player-detail/player-detail.component';
import {LoginComponent} from './login/login.component';
import {AuthGuard} from './auth-guard'

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'players', component: PlayersComponent,canActivate: [AuthGuard] },
  { path: 'dashboard', component: DashboardComponent,canActivate: [AuthGuard] },
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'detail/:id', component: PlayerDetailComponent,canActivate: [AuthGuard] },
];

@NgModule({
  imports: [   RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }



