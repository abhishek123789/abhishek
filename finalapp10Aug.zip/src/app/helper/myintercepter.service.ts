import { Injectable } from '@angular/core';
import { HttpInterceptor,HttpRequest,HttpHandler,HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MyLocalstorageService } from './localstorage.service';

@Injectable({
  providedIn: 'root'
})
export class MyintercepterService implements HttpInterceptor {

  constructor(private _storage : MyLocalstorageService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>{
    let token = this._storage.getObjectValue("TOKEN");
    let clone = req.clone({headers : req.headers.set("Authorization","Bearer "+ token)})
    return next.handle(clone);
  }
}
