import { TestBed, inject } from '@angular/core/testing';

import { NavigationGaurdService } from './navigation-gaurd.service';

describe('NavigationGaurdService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NavigationGaurdService]
    });
  });

  it('should be created', inject([NavigationGaurdService], (service: NavigationGaurdService) => {
    expect(service).toBeTruthy();
  }));
});
