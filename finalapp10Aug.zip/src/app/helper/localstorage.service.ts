import { Injectable } from '@angular/core';
import { LocalStorageService } from 'ng2-localstorage';

@Injectable({
  providedIn: 'root'
})
export class MyLocalstorageService {

  constructor( private _storage : LocalStorageService ) { }

  getObjectValue(key : string){
    var item = <string>this._storage.get(key);
    if (item)
        return item;
    return null;
  }

  setObjectValue(key : string, value : any){
    if(value != undefined && value != null && value != ""){
      this._storage.set(key, JSON.stringify(value));
    }
  }
}
