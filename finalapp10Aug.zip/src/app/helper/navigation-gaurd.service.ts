import { Injectable } from '@angular/core';
import { MyLocalstorageService } from './localstorage.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class NavigationGaurdService {

  constructor(private _storage : MyLocalstorageService,
              private _route : Router) { }

  canActivate(){
    let token = this._storage.getObjectValue("TOKEN");
    console.log(token)
    if(token != undefined && token != null){
        return true;
    }
    else{
      this._route.navigate(["./Login"]);
    }
  }
}
