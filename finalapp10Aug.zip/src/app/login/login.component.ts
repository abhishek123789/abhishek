import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { LoginService } from  './login.service';
import { MyLocalstorageService } from '../helper/localstorage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection : ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit {
  form : FormGroup;
  constructor(private _fb : FormBuilder,
              private _login : LoginService,
              private _router : Router,
              private _storage : MyLocalstorageService) { 
    this.form = this._fb.group({
      'email' : ['',[Validators.required, Validators.email]],
      'password' : ['', [Validators.required]]
    })
  }

  submit(value){
    this._login.loginUser(value)
        .subscribe( response => {
          this._storage.setObjectValue("TOKEN",response.token);
          this._router.navigate(['./UserList']);
        },
        error => {
          console.log(error)
        })
  }

  ngOnInit() {
  }

}
