import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class LoginService {

  constructor(private _client : HttpClient ) { }

  loginUser(data) : Observable<any> {
    let url = "https://reqres.in/api/login";
    let body = JSON.stringify(data);
    let _header = new HttpHeaders().set('content-type', 'application/json');
    return this._client.post(url, body, { headers:_header })
  }
}
