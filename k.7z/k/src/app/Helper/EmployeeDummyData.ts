import {InMemoryDbService} from 'angular-in-memory-web-api';
 export class TestData implements InMemoryDbService{
     createDb(){
         let employeeList=[
            {
              "id": 1,
              "first_name": "kushagra",
              "last_name": "kurl",
              "email": "kkurl@gmail.com"
            }
          
          ]
          return {employees:employeeList}
     }
 }
