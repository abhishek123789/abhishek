import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { LocalStorageHelper } from '../helper/localStorageHelper';

@Component({
  selector: 'navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.css']
})
export class NavigationBarComponent implements OnInit {

  loggedIn: boolean = false;

  applicationTitle : string = "Angular Material Assignment";
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
    
  constructor(
    private breakpointObserver: BreakpointObserver, 
    private _localStorage: LocalStorageHelper
  ) {  }
  
  ngOnInit() {
    console.log("this.isLoggedIn() : " + this.isLoggedIn());
    this.loggedIn = this.isLoggedIn();
  }

  isLoggedIn(): boolean {
    return this._localStorage.getAuthToken("AUTH_TOKEN") != null;
  }

  logout() {
    console.log("Logout method called.");
    this._localStorage.deleteAuthToken("AUTH_TOKEN");
    this.ngOnInit();
  }

  }
