import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { LocalStorageHelper } from '../helper/localStorageHelper';
import { NavigationBarComponent } from '../navigation-bar/navigation-bar.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  hide: boolean = true;
  errorMessage: string;

  constructor(
    private _formBuilder: FormBuilder, 
    private _router: Router, 
    private _login: LoginService,
    private _localStorage: LocalStorageHelper,
    private nav: NavigationBarComponent
  ) {
    this.loginForm = this._formBuilder.group({
      'email': ['', [Validators.required, Validators.email]],
      'password': ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]]
    })
  }

  ngOnInit() {
  }

  onLoginSubmit(value) {
    console.log('EMAIL: ' + value.email + ', PASSWORD: ' + value.password);
    this._login.loginUser(value)
      .subscribe((response) => {
        console.log('response.token: ' + response.token);
        if (response.token != undefined || response.token != "") {
          this._localStorage.setAuthToken("AUTH_TOKEN", response.token);
          
          // This is temporary solution to hide and show the navigation panel items... 
          // Working on child routes
          this.nav.ngOnInit();
          
          this._router.navigate(['/dashboard']);
        }
      },
        (error) => {
          this.errorMessage = "Error in service, Please try later."
        })
  }
}
