import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private _client: HttpClient) { }

  getUsers(): Observable<any> {
    let url = "https://reqres.in/api/users";
    let _header = new HttpHeaders().set('content-type', 'application/json');
    return this._client.get<Observable<UserModel>>(url, { headers: _header })
  }
}
