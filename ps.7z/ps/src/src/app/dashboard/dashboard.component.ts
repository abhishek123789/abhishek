import { Component } from '@angular/core';
import { DashboardService } from './dashboard.service';
import { UserModel } from '../models/user.model';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
 
  errorMessage: string;
  userModels: UserModel[];

  constructor(private _dashboardService : DashboardService) {

  }

  ngOnInit() {
    this.getUsersList();
  }

  getUsersList() {
    this._dashboardService.getUsers().subscribe((response) => {
      this.userModels = response.data;
      console.log(this.userModels);
      console.log(response.data);
    },
      (error) => {
        this.errorMessage = "Error in service, Please try later."
      });
  }

}
