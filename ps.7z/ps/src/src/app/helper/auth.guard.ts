import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { LocalStorageHelper } from './localStorageHelper';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  
  constructor(private _localStorage: LocalStorageHelper, private router: Router) {
    
  }
  canActivate() {
    let auth_token = this._localStorage.getAuthToken("AUTH_TOKEN");
    console.log("AuthGuard - auth_token : " + auth_token);
    if (auth_token == "undefined" || auth_token == "" || auth_token == null) {
      this.router.navigate(['/login']);
      return false;
    } else {
      return true;
    }
  }
}
