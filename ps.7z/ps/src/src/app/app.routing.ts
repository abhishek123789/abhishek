﻿import { Routes, RouterModule } from '@angular/router';
import { FirstPageComponent } from './first-page/first-page.component';
import { SecondPageComponent } from './second-page/second-page.component';
import { ThirdPageComponent } from './third-page/third-page.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';

// import { HomeComponent } from './home/index';
// import { LoginComponent } from './login/index';
// import { RegisterComponent } from './register/index';
import { AuthGuard } from './helper/auth.guard';
import { LoginAuthGuard } from './helper/login-auth.guard';


const appRoutes: Routes = [
    // { path: '', component: LoginComponent, pathMatch: 'full' },
    // { path: 'first-page', component: FirstPageComponent, canActivate: [AuthGuard]  },
    // { path: 'second-page', component: SecondPageComponent, canActivate: [AuthGuard]  },
    // { path: 'third-page', component: ThirdPageComponent, canActivate: [AuthGuard]  },
    // { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
    // // otherwise redirect to home
    // { path: '**', redirectTo: '' }
        {path : 'first-page', component: FirstPageComponent , canActivate : [AuthGuard] },
        {path : 'second-page', component: SecondPageComponent , canActivate : [AuthGuard] },
        {path : 'third-page', component: ThirdPageComponent , canActivate : [AuthGuard] },
        {path : 'dashboard', component : DashboardComponent, canActivate : [AuthGuard] },
        {path : 'login', component : LoginComponent, canActivate : [LoginAuthGuard]},
        { path: '', component: DashboardComponent, canActivate: [AuthGuard] }
];

export const routing = RouterModule.forRoot(appRoutes);