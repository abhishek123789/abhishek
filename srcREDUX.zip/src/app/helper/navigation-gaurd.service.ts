import { Injectable } from '@angular/core';
import { MyLocalstorageService } from './localstorage.service';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavigationGaurdService {

  constructor(private _storage : MyLocalstorageService,
              private _route : Router,
            private _store : Store<any>) { }

  canActivate(){
    let token;
    this.returnStore().subscribe(state => {
      if(state != undefined || state != null){
       token = state.logintoken;
      }
    });
    console.log(token)
    if(token != undefined && token != null){
        return true;
    }
    else{
      this._route.navigate(["./Login"]);
    }
  }

  returnStore() : Observable<any> {
    return this._store.select('loginReducer');
  }
}
