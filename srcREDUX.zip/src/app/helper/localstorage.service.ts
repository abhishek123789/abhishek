import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyLocalstorageService {

  constructor( ) { }

  getObjectValue(key : string){
    var item = null;//<string>this._storage.get(key);
    if (item)
        return item;
    return null;
  }

  setObjectValue(key : string, value : any){
    if(value != undefined && value != null && value != ""){
      null;//this._storage.set(key, JSON.stringify(value));
    }
  }
}
