import { Injectable } from '@angular/core';
import { HttpInterceptor,HttpRequest,HttpHandler,HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MyLocalstorageService } from './localstorage.service';

import { Store } from '@ngrx/store';

@Injectable({
  providedIn: 'root'
})
export class MyintercepterService implements HttpInterceptor {

  constructor(private _storage : MyLocalstorageService, private _store : Store<any>) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>{
    let token;
    this.returnStore().subscribe(state => {
      token = state.logintoken;
    })
    console.log("intercept : " + token);
    let clone = req.clone({headers : req.headers.set("Authorization","Bearer "+ token)})
    return next.handle(clone);
  }

  returnStore() : Observable<any> {
    return this._store.select('loginReducer');
  }
}
