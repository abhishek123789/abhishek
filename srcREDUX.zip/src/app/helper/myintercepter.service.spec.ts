import { TestBed, inject } from '@angular/core/testing';

import { MyintercepterService } from './myintercepter.service';

describe('MyintercepterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyintercepterService]
    });
  });

  it('should be created', inject([MyintercepterService], (service: MyintercepterService) => {
    expect(service).toBeTruthy();
  }));
});
