import { ADD_TOKEN, REMOVE_TOKEN } from '../action/action';

export class Login{
    logintoken : string
}

export const initialLoginState : Login = {
    logintoken : null
}

export function loginReducer(state = initialLoginState, action) : Login {
    switch(action.type){
        case ADD_TOKEN : {
            return {
                ...state,
                logintoken : action.payload
            }
        }
        case REMOVE_TOKEN : {
            return {
                ...state,
                logintoken : null
            }
        }
    }
}

export function UserReducer(state = initialLoginState, action) : Login {
    switch(action){
        case ADD_TOKEN : {
            return {
                ...state,
                logintoken : action.payload
            }
        }
        case REMOVE_TOKEN : {
            return {
                ...state,
                logintoken : null
            }
        }
    }
}