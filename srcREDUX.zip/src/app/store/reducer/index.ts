import { loginReducer, UserReducer } from './reducer';
import { ActionReducerMap } from '@ngrx/store';

import { Login } from './reducer';

interface AppStore{
    loginReducer : Login;
    userReducer : Login;
}

export const reducers : ActionReducerMap<AppStore> = {
    loginReducer : loginReducer,
    userReducer : UserReducer
}