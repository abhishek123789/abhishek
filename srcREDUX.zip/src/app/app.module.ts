import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { StoreModule } from '@ngrx/store';

import { LoginService } from './login/login.service';
import { NavigationGaurdService } from './helper/navigation-gaurd.service';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserListComponent } from './user-list/user-list.component';

import { reducers } from './store/reducer/index';

const route : Routes = [
  { path : '', redirectTo : 'Login', pathMatch:"full" },
  { path:"Login", component:LoginComponent },
  { path:"UserList", component:UserListComponent, canActivate : [NavigationGaurdService]},
  { path: "**", redirectTo : 'Login' }
]

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpModule,
    StoreModule.forRoot(reducers,{}),
    RouterModule.forRoot(route)
  ],
  providers: [LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
