import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private _client : HttpClient ) { }

  getUserList() : Observable<any> {
    let url = "https://jsonplaceholder.typicode.com/users";
    let _header = new HttpHeaders().set('content-type', 'application/json');
    return this._client.get(url, { headers:_header })
  }
}
