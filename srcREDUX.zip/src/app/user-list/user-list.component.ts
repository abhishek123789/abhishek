import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  constructor(private _user : UserService) { }

  ngOnInit() {
    this._user.getUserList()
        .subscribe(resp => {
          console.log(resp)
        },
        error => {
          console.log(error)
        }
      )
  }

}
