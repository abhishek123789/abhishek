import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appRenderStyle]'
})
export class RenderStyleDirective {

  constructor(private element : ElementRef) { 
    this.element.nativeElement.style.color = 'red';
  }

}
