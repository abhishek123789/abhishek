import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-student-search',
  templateUrl: './student-search.component.html',
  styleUrls: ['./student-search.component.css']
})
export class StudentSearchComponent implements OnInit {
  @Input() searchText : string;
  @Output() search = new EventEmitter<string>();

  employee : Employee = {
    Id : 1,
    name : 'Pruthwi'
}
  constructor() { }

  ngOnInit() {
    console.log(this.searchText);
  }
  

  onclickButton()
  {
    console.log(this.employee)
  }

  OnStudentSearch(studentName: string){
    this.search.emit(studentName);
  }

}

class Employee{
  name :string;
  Id : number;
}
