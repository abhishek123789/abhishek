import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class LoginService {
    constructor(private _http: Http) { }

    loginUser(data): Observable<any> {
        let url = 'https://reqres.in/api/login';
        let body = JSON.stringify(data);
        var header = new Headers();
        
        console.log(body)
        header.append('Access-Control-Allow-Origin', '*');
        header.append("Content-Type", "application/json");
        header.append("accept", "application/json");
        let options = new RequestOptions({ headers: header });
        return this._http.post(url,body,options)
                    .pipe(map((response) => response.json()))
    }
}

