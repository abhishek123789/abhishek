import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router'
import { LoginService } from './login.service';
import { LocalStorageHelper } from '../helper/localstorage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm : FormGroup;
  constructor(private fb : FormBuilder, 
    private _login : LoginService, 
    private _router : Router,
    private _localStorageHelper : LocalStorageHelper) {
      this.loginForm = this.fb.group({
        'email' : ['',[Validators.required, Validators.email]],
        'password' : ['',[Validators.required]]
      })
   }

  ngOnInit() {
  }

  submit(value){
    this._login.loginUser(value)
        .subscribe(resp => {
          console.log(resp)
          this._localStorageHelper.setObjectValue("TOKEN", resp.token);
          this._router.navigateByUrl('StudentList');
        })
  }

}
