import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user-list/user';

import { ActivatedRoute }  from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user = new User;
  constructor(private _user : UserService,
              private _route : ActivatedRoute) { }

  ngOnInit() {
    let id = this._route.snapshot.params["userId"];
    this._user.getUser(id)
    .subscribe( resp => {
      this.user = resp;
    },
    error => {
      console.log("Error Found : " + error)
    })
  }

}
