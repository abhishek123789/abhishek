import { Injectable } from "@angular/core";

@Injectable()
export class Validate{
    public phoneNumberValidator(){
        return true;
    }
}