import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Student } from '../template-driven/student';
import { Validate } from './validators';

@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css']
})
export class ReactiveFormsComponent implements OnInit {
  form : FormGroup;
  genders:any[] = ['Male','Female'];
  constructor(private fb : FormBuilder, private validate : Validate) {
      this.form = this.fb.group({
        'studentId': ['',[Validators.required]],
        'studentName':['',[Validators.required]],
        'gender':['',[Validators.required]]
      })
   }

  ngOnInit() {

    this.form.controls['studentId'].setValue(1);
  }


  onSubmit(value : any){
    console.log(value)
  }

}
