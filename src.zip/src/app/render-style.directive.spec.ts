import { RenderStyleDirective } from './render-style.directive';

describe('RenderStyleDirective', () => {
  it('should create an instance', () => {
    const directive = null;//new RenderStyleDirective();
    expect(directive).toBeTruthy();
  });
});
