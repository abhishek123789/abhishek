import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import{ FormsModule, ReactiveFormsModule } from '@angular/forms'
import { RouterModule, Routes, Route } from '@angular/router';
import { HttpModule } from '@angular/http';

import { LocalStorageService } from 'ng2-localstorage';

import { Validate } from './reactive-forms/validators'

import { AppComponent } from './app.component';
import { DemocomponentComponent } from './democomponent/democomponent.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentSearchComponent } from './student-search/student-search.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { RenderStyleDirective } from './render-style.directive';
import { ReverseStringPipe } from './reverse-string.pipe';
import { SingleStudentComponent } from './single-student/single-student.component';

import { UserService } from './user.service';
import { LoginService } from './login/login.service';
import { UserComponent } from './user/user.component';
import { UserListComponent } from './user-list/user-list.component';
import { LoginComponent } from './login/login.component';

import { LocalStorageHelper } from './helper/localstorage';
import { NavigationGaurdHelper } from './helper/navigationgaurd';

const route : Routes = [
  { path : '', redirectTo : 'Login', pathMatch : 'full' },
  { path : 'Login', component: LoginComponent },
  { path : 'StudentList', component : StudentListComponent, canActivate : [NavigationGaurdHelper] },
  { path : 'UserList', component : UserListComponent, canActivate : [NavigationGaurdHelper]  },
  { path : 'User/:userId', component : UserComponent, canActivate : [NavigationGaurdHelper]  },
  { path : 'Student/:studentId', component : SingleStudentComponent, canActivate : [NavigationGaurdHelper]  },
  { path : 'ReactiveForms', component : ReactiveFormsComponent, canActivate : [NavigationGaurdHelper]   } ,
  { path : 'TemplateForms', component : TemplateDrivenComponent, canActivate : [NavigationGaurdHelper]  },
  { path : '**',  redirectTo : 'Login', pathMatch : 'full' }
]

@NgModule({
  declarations: [
    AppComponent,
    DemocomponentComponent,
    StudentListComponent,
    StudentSearchComponent,
    TemplateDrivenComponent,
    ReactiveFormsComponent,
    RenderStyleDirective,
    ReverseStringPipe,
    SingleStudentComponent,
    UserComponent,
    UserListComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(route)
  ],
  providers: [
    Validate,
    UserService,
    LoginService,
    LocalStorageService,
    LocalStorageHelper,
    NavigationGaurdHelper
  ],
  bootstrap: [AppComponent]
})
export class RootModule { }
