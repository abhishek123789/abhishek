import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from './user-list/user'

@Injectable()
export class UserService {

  constructor(private _http : Http) { }

  getUsersList() : Observable<User[]> {
    let url = "https://jsonplaceholder.typicode.com/users";
    var header = new Headers();
    header.append('Access-Control-Allow-Origin', '*');
    header.append("Content-Type", "application/json");
    header.append("accept", "application/json");
    let options = new RequestOptions({headers : header});
    return this._http.get(url, options)
              .pipe(map((response)=> response.json()))
  }

  getUser(id) : Observable<User> {
    let url = "https://jsonplaceholder.typicode.com/users/"+id;
    var header = new Headers();
    header.append('Access-Control-Allow-Origin', '*');
    header.append("Content-Type", "application/json");
    header.append("accept", "application/json");
    let options = new RequestOptions({headers : header});
    return this._http.get(url, options)
              .pipe(map((response)=> response.json()));
  }
}
