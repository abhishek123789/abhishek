import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverseString'
})
export class ReverseStringPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if(value != undefined){
      if(args)
        return value.split("").reverse().join("");
      else
        return value
    }
  }
}
