import { CanActivate, Router } from '@angular/router';
import { Injectable } from '@angular/core';

import { LocalStorageHelper } from './localstorage';

@Injectable()
export class NavigationGaurdHelper {
    constructor(private _localStorage : LocalStorageHelper, private _route : Router){}

    canActivate(){
        let token = this._localStorage.getObjectValue("TOKEN");
        if(token != undefined && token != "" && token != null){
            return true;
        }
        else{
            this._route.navigateByUrl('Login');
            
        }
    }
}