import { Injectable } from '@angular/core';

import { LocalStorageService } from 'ng2-localstorage';

@Injectable()
export class LocalStorageHelper{
    USER_AUTHORIZATION_TOKEN : string;
    constructor(private _localStorage : LocalStorageService){}

    setObjectValue(key:any, value:any) {
        this._localStorage.set(key, JSON.stringify(value));
    }

    getObjectValue(key:any) {
        var item = this._localStorage.get(key);
        console.log(item)
        if (item)
            return item;
        return null;
    }

    getUserAuthenticationToken() {
        return this._localStorage.get(this.USER_AUTHORIZATION_TOKEN);
    }

    setUserAuthenticationToken(token:any) {
        this._localStorage.set(this.USER_AUTHORIZATION_TOKEN, token);
    }
}
