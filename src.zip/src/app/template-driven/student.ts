export class Student{
    studentId:number;
    studentName : string;
    gender : string;
}